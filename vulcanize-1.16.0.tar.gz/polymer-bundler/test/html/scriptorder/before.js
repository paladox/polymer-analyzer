
console.log("Hello from before.js!");

window.BeforeJs = { value: 77 };