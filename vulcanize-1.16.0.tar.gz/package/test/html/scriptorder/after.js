
console.log("Hello from after.js! BeforeJs.value = " + BeforeJs.value);
